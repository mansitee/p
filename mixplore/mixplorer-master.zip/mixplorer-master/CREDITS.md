# Credits

## Tools

- [rsvg-convert](https://gitlab.gnome.org/GNOME/librsvg) ([GNU](https://gitlab.gnome.org/GNOME/librsvg/-/raw/main/COPYING.LIB))
- [CairoSVG](https://github.com/Kozea/CairoSVG) ([GNU](https://raw.githubusercontent.com/Kozea/CairoSVG/main/LICENSE))

## Icons

- [Iconsax](https://github.com/glenthemes/iconsax) ([LICENSE](https://iconsax.io/#license))
- [Tabler Icons](https://github.com/tabler/tabler-icons) ([MIT](https://github.com/tabler/tabler-icons/blob/master/LICENSE))
- [SVG Repo](https://www.svgrepo.com) ([LICENSE](https://www.svgrepo.com/page/licensing/))

## Fonts

- [Fira Code](https://github.com/tonsky/FiraCode) ([MIT](https://github.com/tonsky/FiraCode/blob/master/LICENSE))
- [Google Fonts](https://fonts.google.com/) ([OFL](https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL), _etc._)

## Forums

- [FatalBulletHit@xda-developers](https://forum.xda-developers.com/t/mixplorer-q-a-and-faq-user-manual.3308582/post-78541319)
- [TheMystic@xda-developers](https://forum.xda-developers.com/t/tutorial-mixplorer-themes-skins-how-to-make-them.4202319/)
