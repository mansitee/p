### [MiXplorer](https://mixplorer.com/)

#### Install manually

Download the `dracula-{accent_name}.mit` file from the latest release [here](https://github.com/dracula/mixplorer/releases)

#### Activating theme

1. Open MiXplorer
2. Select the file `dracula-{accent_name}.mit`
3. Then select `Import`

#### Troubleshooting

If the theme is not applying properly, follow this method [here](https://github.com/dracula/mixplorer/wiki/Troubleshooting#fixtheme)
