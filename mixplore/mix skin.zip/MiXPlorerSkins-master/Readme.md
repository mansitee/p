# Changelog
2019.01.02
Mover the repo from Bitbucket to Github

2019.01.03
Update skins and screenshots

2019.03.22
Update Readme.md for international users' convinence


# Descriptions
Fore details, please refer to [Descriptions.xlsx](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/Descriptions.xlsx) or refer to [XDA user @FatalBulletHit's illustration](https://i.imgur.com/Wmhsm12.jpg)


[FatalBulletHit Original Post](https://forum.xda-developers.com/showpost.php?p=78541319&postcount=733)


# Skins
![Collections](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/Screenshots/Collections.png)


### [Blue (Click to view Skin Code)](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/txt/Blue.txt)
![Blue](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/Screenshots/Blue.png)


### [Blue Gray (Click to view Skin Code)](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/txt/Blue%20Gray.txt)
![Blue Gray](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/Screenshots/Blue%20Gray.png)


### [Bright Green (Click to view Skin Code)](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/txt/Bright%20Green.txt)
![Bright Green](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/Screenshots/Bright%20Green.png)


### [Green (Click to view Skin Code)](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/txt/Green.txt)
![Green](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/Screenshots/Green.png)


### [Indigo (Click to view Skin Code)](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/txt/Indigo.txt)
![Indigo](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/Screenshots/Indigo.png)


### [Orange (Click to view Skin Code)](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/txt/Orange.txt)
![Orange](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/Screenshots/Orange.png)


### [Pink (Click to view Skin Code)](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/txt/Pink.txt)
![Pink](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/Screenshots/Pink.png)


### [Purple (Click to view Skin Code)](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/txt/Purple.txt)
![Purple](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/Screenshots/Purple.png)


### [Red (Click to view Skin Code)](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/txt/Red.txt)
![Red](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/Screenshots/Red.png)


### [Teal (Click to view Skin Code)](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/txt/Teal.txt)
![Teal](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/Screenshots/Teal.png)


### [Yellow (Click to view Skin Code)](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/txt/Yellow.txt)
![Yellow](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/Screenshots/Yellow.png)


### [Night Mode (Click to view Skin Code)](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/txt/Night%20Mode.txt)
![Night Mode](https://raw.githubusercontent.com/YandLiu/MiXPlorerSkins/master/Screenshots/Night%20Mode.png)
