# Contributors

Please feel free to raise an [issue](https://github.com/EddieJaoudeCommunity/awesome-github-profiles/issues) with ideas / suggestions or other GitHub profiles you think are awesome!

Join the conversation in our [Discord community](http://discord.eddiehub.org)
