---
name: Frontend Submission
about: 'This can be used to submit a frontend (alternatively to PRs) '
labels: Suggestion
assignees: digitalblossom

---

URL: https://example.com
