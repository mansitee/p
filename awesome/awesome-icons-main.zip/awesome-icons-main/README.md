# 🎨 awesome-icons

[![Awesome](https://awesome.re/badge-flat2.svg)](https://awesome.re)

___
Not maintained, please use Iconify, Icones or React Icons

https://icones.netlify.app/
https://iconify.design/
https://react-icons.github.io/
___

List of free icon sets for UI design

Note: Make sure to check the licenses before using. Some might require linking back to the source and/or license for instance.

*Feel free to contribute an icon set via [Issues](https://github.com/digitalblossom/awesome-icons/issues)!*

--- 

- 🌰 https://akaricons.com/
- 📘 https://blueprintjs.com/docs/#icons
- 🐣 https://feathericons.com/
- 8️⃣ https://icons8.com/
- 🔎 https://iconscout.com/unicons
- ♥ https://akveo.github.io/eva-icons/
- 🔢 https://www.zwicon.com/
- 🏴 https://iconoir.com/
- 🏨 https://iconhub.io/
- ⭐ https://iconic.app/
- 🦸 https://heroicons.com/
- 🧪 https://phosphoricons.com/
- 🍓 https://jam-icons.com/
- 🛠️ https://tablericons.com/
- 🎶 https://remixicon.com/
- ♾️ https://lineicons.com/
- ⚛️ https://ionic.io/ionicons
- 📐 https://fonts.google.com/icons
- 🏞️ https://iconpark.oceanengine.com/official

### Animated
- 👑 https://lordicon.com/icons 

### Lists
- https://www.uigoodies.com/?category=Icons
- https://react-icons.github.io/react-icons/

