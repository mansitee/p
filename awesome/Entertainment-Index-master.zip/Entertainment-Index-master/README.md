## Entertainment Index

Get recommended site's to watch / read movie, series, Anime, Manga, light Novel, Etc. Also Some Application To browse these contents.

## 🚸 Warnings :

- This is Just For Educational Purpose
- DO NOT Sell this Script, This is 💯% Free

## 🤗 Meet Me :

• 😪 check you did all things perfectly before contacting [ Warning ] <br>

• For any Support About Script contact [@OshekherO](https://t.me/OshekherO) at Telegram <br>

---
<h4 align='center'>© 2022 ツ ѕнєкнєя</h4>

<!-- DO NOT REMOVE THIS CREDIT 🤬 🤬 -->

