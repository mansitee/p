# Programmer's-wiki
Collection of best websites a Programmer should visit.
This website can be visited [here](http://sumanjay.me/pw/)

# Report correction
Any broken link or typos can be reported [here](http://sumanjay.me/pw/#report)

# Credits
-Source: sdmg15 & al for maintaining [this](https://github.com/sdmg15/Best-websites-a-programmer-should-visit/)

-Avatar Image: [Freepik](freepik.com)

-Icons: [Font Awesome](fortawesome.github.com/Font-Awesome)

-Animation: Daniel Eden @daneden for animate.css

-[jQuery](jquery.com)

-html5shiv.js (@afarkas @jdalton @jon_neal @rem)

-[CSS3 Pie](css3pie.com)

-[Respond.js](j.mp/respondjs)

-[Skel](skel.io)
