## Deprecated, missing docs or proprietary contents

- [OnlyOffice](https://www.onlyoffice.com/) - Office suite available for Android, GNU/Linux, iOS, macOS, Windows. **(This app is _proprietary).** 
