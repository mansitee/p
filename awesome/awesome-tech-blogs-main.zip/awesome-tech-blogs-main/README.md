# Awesome Tech Blogs.⚡

Add your blog in [`data.js`](./data.js).

Visit [tech-blogs.dev](https://tech-blogs.dev/).

> Inspired by [Wes Bos's](https://wesbos.com/) [`/uses`](https://uses.tech/) page.
