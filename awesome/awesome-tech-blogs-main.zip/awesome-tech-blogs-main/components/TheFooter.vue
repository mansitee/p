<template>
  <footer class="text-center">
    <p>
      Made by <a href="https://markodenic.com">Marko Denic</a> with <a href="https://nuxtjs.org">Nuxt.js</a>. Icons from <a href="https://www.freepik.com/">Freepik</a>.
    </p>

    <p>
      Marko also made <a href="https://javascriptquiz.com">JavaScript Quiz</a> and <a href="https://freecodetools.org">Free Code Tools</a>.
    </p>

    <p>
      Source on <a href="https://github.com/MarkoDenic/awesome-tech-blogs">GitHub</a>. Add yourself!
    </p>

    <p>
      Hosted on <a href="https://www.netlify.com/">Netlify</a>.
    </p>

    <p>
      Inspired by <a href="https://wesbos.com/">Wes Bos's</a> <a href="https://uses.tech/">uses.tech</a> page.
    </p>
  </footer>
</template>
