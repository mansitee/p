<template>
  <header
    id="top"
    class="text-center pb-6"
  >
    <a href="/">
      <img
        src="/logo.svg"
        width="70"
        height="70"
        alt="Awesome Tech Blogs"
      />
    </a>

    <h1>
      Tech blogs
    </h1>

    <p>
      This is a list of Awesome Tech Blogs.
    </p>
  </header>
</template>
