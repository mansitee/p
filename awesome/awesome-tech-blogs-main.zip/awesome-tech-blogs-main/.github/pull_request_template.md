<!--

Please read the requirements corresponding to your pull request before you submit. You can delete this before you PR 

## What's a Awesome Blogs Page?

It's a collection of Tech Blogs.

## Adding Yourself

* Ensure you are linking to a blog page, not to your front-page, except your front-page is your blog page. :)
* Ensure you're writing about tech.
* Ensure you're using single quotes for property values.
* Ensure you added yourself somewhere random, and not at the end of the file, so we avoid merge conflicts.
* Ensure your data is formatted like other entries. 
* Add up to 10 tags!
* Ensure this PR has a title in the following format: "Add Your Name Blog"

-->
