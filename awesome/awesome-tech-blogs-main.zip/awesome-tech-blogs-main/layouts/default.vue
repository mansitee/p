<template>
  <div class="wrapper">
    <TheHeader />

    <main>
      <Nuxt />
    </main>

    <TheFooter />
  </div>
</template>
