
export default {
  name: 'items',
  items: [
    // #calendars    
{name: 'vue-social-sharing', group: 'ui-components', link: 'https://github.com/nicolasbeauvais/vue-social-sharing) - A Vue.js component for sharing links to social networks, work with Vue.js 1.X or 2.X.
  ]
}
