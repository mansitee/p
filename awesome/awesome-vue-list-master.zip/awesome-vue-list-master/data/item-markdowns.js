
export default {
  name: 'items',
  items: [
    // #calendars     
    
{name: 'vue-markdown', group: 'ui-components', link: 'https://github.com/miaolz123/vue-markdown) - A Powerful and Highspeed Markdown Parser for Vue.
{name: 'vue-mavonEditor', group: 'ui-components', link: 'https://github.com/hinesboy/mavonEditor) - A markdown editor based on Vue that supports a variety of personalized features.
{name: 'vue-simple-markdown', group: 'ui-components', link: 'https://github.com/Vivify-Ideas/vue-simple-markdown) - A Simple and Highspeed Markdown Parser for Vue.
  ]
}
