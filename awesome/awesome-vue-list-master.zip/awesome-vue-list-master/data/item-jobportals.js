
export default {
  name: 'items',
  items: [
    // #job-portal
    {name: 'Vue.js Jobs - VueJobs', group: 'job-portal', link: 'https://vuejobs.com/', description:  'A Vue.js job portal to hire or get hired for all your Vue.js jobs.'},
  ]
}
