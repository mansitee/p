
export default {
  name: 'items',
  items: [
    // #calendars     
    
{name: 'vue-qriously', group: 'ui-components', link: 'https://github.com/theomessin/vue-qriously) - A Vue.js 2 component to draw QR codes on an HTML Canvas using qrious.
{name: 'vue-qart', group: 'ui-components', link: 'https://github.com/superman66/vue-qart) - The directive of vue 2.x for qart.js.

  ]
}
