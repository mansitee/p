
export default {
  name: 'items',
  items: [
    // #books
    {name: 'The Majesty Of Vue.js', group: 'books', link: 'https://www.packtpub.com/web-development/majesty-vuejs', author: 'Alex Kyriakidis & Kostas Maniatis, Packt. (Nov 2016'}, 
    {name: 'Learning Vue.js 2', group: 'books', link: 'https://www.packtpub.com/web-development/learning-vuejs-2', author: 'Olga Filipova, Packt. (Dec 2016'}, 
    {name: 'The Majesty Of Vue.js 2', group: 'books', link: 'https://leanpub.com/vuejs2', author: 'Alex Kyriakidis and Kostas Maniatis, Leanpub. (Mar 2017'}, 
    {name: 'Vue.js 2 Cookbook', group: 'books', link: 'https://www.packtpub.com/web-development/vuejs-2-cookbook', author: 'Andrea Passaglia, Packt. (May 2017'}, 
    {name: 'Vue.js in Action', group: 'books', link: 'https://www.manning.com/books/vue-js-in-action', author: 'Erik Hanchett and Benjamin Listwon (Spring 2018'}, 
  ]
}
