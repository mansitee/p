
export default {
  name: 'items',
  items: [
    // #calendars     

    { name: 'vue-pdf', group: 'ui-components', link: 'https://github.com/FranckFreiburger/vue-pdf) - A pdf viewer based on mozilla's PDF.js

  ]
}
