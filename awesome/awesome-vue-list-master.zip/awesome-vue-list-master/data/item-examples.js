
export default {
  name: 'items',
  items: [
    // #official-examples
    {name: 'Basic Examples', group: 'official-examples', link: 'http://vuejs.org/guide/'}, 
    {name: 'Vue.js TodoMVC', group: 'official-examples', link: 'https://github.com/vuejs/vue/tree/dev/examples/todomvc'}, 
    {name: 'CoffeeScript Version', group: 'official-examples', link: 'https://github.com/anfelor/TodoMVC-CoffeeScript-and-Vue.js'}, 
    {name: 'Vue.js HackerNews Clone', group: 'official-examples', link: 'https://github.com/vuejs/vue-hackernews'}, 
    {name: 'Vue.js 2.0 HackerNews Clone', group: 'official-examples', link: 'https://github.com/vuejs/vue-hackernews-2.0'}, 
    
  ]
}
