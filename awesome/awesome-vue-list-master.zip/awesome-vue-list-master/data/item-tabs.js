
export default {
  name: 'items',
  items: [
    // #calendars     
    
{name: 'vue-tabs', group: 'ui-components', link: 'https://github.com/cristijora/vue-tabs) - Simple tabs and pills.
{name: 'vue-swipe-tabs', group: 'ui-components', link: 'https://github.com/zhangxiang958/vue-tab) - A touch swipe tab component for vue.js(vue2).
  ]
}
