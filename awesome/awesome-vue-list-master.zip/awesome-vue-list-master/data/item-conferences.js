
export default {
  name: 'items',
  items: [
    // #conference
    {name: 'VueConf', group: 'conferences', link: 'http://conf.vuejs.org'}, 
    {name: 'Vue.js London', group: 'conferences', link: 'http://vuejs.london'}, 
  ]
}
