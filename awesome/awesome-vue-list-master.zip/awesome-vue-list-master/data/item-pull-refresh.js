
export default {
  name: 'items',
  items: [
    // #calendars     
    {name: 'vue-pull-refresh', group: 'ui-components', link: 'https://github.com/lakb248/vue-pull-refresh) - A pull to refresh component for Vue.js 2.0.
    {name: 'vue-pull-to', group: 'ui-components', link: 'https://github.com/stackjie/vue-pull-to) - A pull-down refresh and pull-up load more and infinite scroll for Vue.js component.  
  ]
}
