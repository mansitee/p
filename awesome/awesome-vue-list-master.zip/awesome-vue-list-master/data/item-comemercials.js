
export default {
  name: 'items',
  items: [
    // #commercial-products
    {name: 'Wijmo', group: 'commercial-products', link: 'http://wijmo.com/products/wijmo-5/', description: 'A collection of UI controls with VueJS support.'}, 
    {name: 'Collate Notes', group: 'commercial-products', link: 'http://www.collatenotes.com/'}, 
    {name: 'Formester', group: 'commercial-products', link: 'https://www.formester.com/', description: 'Form, email marketing automation made easy'}, 
    {name: 'ChatWoot', group: 'commercial-products', link: 'https://www.chatwoot.com/', description: 'Livechat and agent collaboration over facebook messenger.'}, 
  ]
}
