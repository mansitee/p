### IMPORTANT
Make sure that the changes work on **blogger** before sending a pull request

## Description
Describe your changes here

Live On: *If possible, provide a blogger URL where the proposed changes are implemnted*

**A little Yes / No**
- [ ] This fixes a known Issue(mention issue above).
- [ ] The proposed template code works on Chrome, Firefox and Edge.
- [ ] The proposed template is tested on Mobile and works on it.
