# Change Log

## Unreleased

## [20.0.0] - Oct 12, 2020
### Changed
 - Fixed duplicate canonical URL error
 - Replaced Background images with colors
 - Removed browser prefixes that are no longer needed
 - Fixed some CSS errors

### Removed
 - Removed animations in Blog title
 - Removed Google+ URL
 - Removed Quickedit icons whereever possible
 - Removed template skin for the customize template option. (It was already not working)

### [16.0.0] - Oct 18, 2016
Initial release.
A single amp template which is currently used by me in my blogs is uploaded here.
