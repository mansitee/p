Mohon untu tidak menghapus pemberitahuan ini atau kredit link di bawahnya? 
Jika ingin menghapusnya silahkan Transfer Rp. 100.000, 

Ke No.Rek BANK BRI 022501016056534 
an. Basri Matindas atau

- Hubungi 081241105658 (SMS Only). 

Kalau menghapus tanpa izin, berarti anda maling, BLOGNYA TIDAK BAROKAH DAN PENGHASILAN DARI BLOG ITU HARAM, susah bikin template Mas/Mbak!