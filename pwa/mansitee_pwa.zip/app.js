
function loadPage(jsonFile) {
  fetch(jsonFile)
    .then((response) => response.json())
    .then((data) => {
      const contentElement = document.getElementById('content');
      contentElement.innerHTML = `
        <h1>${data.title}</h1>
        <p>${data.content}</p>
        <a href="#" onclick="loadPage('about.json')">About Us</a> | 
        <a href="#" onclick="loadPage('contact.json')">Contact Us</a>
      `;
    })
    .catch((error) => {
      console.error('Error loading page:', error);
      document.getElementById('content').innerHTML = '<h1>Page not found</h1><p>Sorry, the page could not be loaded.</p>';
    });
}
