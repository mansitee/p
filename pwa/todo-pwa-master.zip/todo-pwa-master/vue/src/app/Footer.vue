<template>
  <footer class="text-center text-gray-500 text-xs">
    Created by
    <a
      href="https://nico.dev"
      target="_blank"
      class="underline hover:text-black"
      >Nico Martin
    </a>
    - Source Code on
    <a
      href="https://github.com/nico-martin/todo-pwa"
      target="_blank"
      class="underline hover:text-black"
    >
      GitHub </a
    ><br />
    <a
      class="inline-block mt-2"
      href="https://todo-pwa.nico.dev/preact/"
      target="_blank"
    >
      Looking for the same in <span class="underline">Preact</span>?
    </a>
  </footer>
</template>
<script>
export default {
  data() {
    return {};
  },
};
</script>
