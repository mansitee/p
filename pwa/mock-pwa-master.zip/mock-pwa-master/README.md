# mock-pwa
A mock progressive web app, using React and mini.css

Read all about it [here](https://hackernoon.com/a-beginners-guide-to-progressive-web-apps-the-frontend-web-424b6d697e35)
