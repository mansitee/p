// Generating content based on the template
const template = `<article>
 
 
 
 
 
 
 <div class='card'>
      <div class='content'>
        <div class='header'>
          
  <img class='profile-pic'src='img/placeholder.png' data-src='img/SLUG.jpg' alt='NAME'>        
          <div class='detail'> <p class='name'><h3>NAME</h3> </p>
            <p class='posted'><strong>AUTHOR</strong> - <a href='http://WEBSITE/'>WEB</a> </p>
          </div>
        </div> <div class='desc'> 
               
    <img class='pict'src='img/placeholder.png' data-src='img/SLUG.jpg' alt='NAME'>   

        KORAN </div>
        <div class='tags'>
          <span><a href='http://js13kgames.com/entries/SLUG'>App://entries/SLUG</a> </span> 
 <span><a href='http://js13kgames.com/entries/GITHUB'>GITHUB://entries/SLUG</a> </span>          
          </div>
        <div class='footer'>
          <div class='like'>
            <span><a href='https://twitter.com/TWITTER'>@TWITTER</a></span>
          </div>
          <div class='comment'>
            <span> ----</span>
          </div>
          <div class='share'>
            
            <span>12k</span>
          </div>
        </div>
      </div>
    </div>
  </div> 
</article>`;
let blog = '';
for (let i = 0; i < games.length; i++) {
  let entry = template.replace(/POS/g, (i + 1))
    .replace(/SLUG/g, games[i].slug)
    .replace(/NAME/g, games[i].name)
    .replace(/AUTHOR/g, games[i].author)
    .replace(/TWITTER/g, games[i].twitter)
    .replace(/WEBSITE/g, games[i].website)
    .replace(/GITHUB/g, games[i].github);
     entry = entry.replace('<a href=\'http:///\'></a>', '-');
  blog += entry;
}
document.getElementById('blog').innerHTML = blog;

// Registering Service Worker
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sima/sw.js');
}

// Requesting permission for Notifications after clicking on the button
const button = document.getElementById('notifications');
button.addEventListener('click', () => {
  Notification.requestPermission().then((result) => {
    if (result === 'granted') {
      randomNotification();
    }
  });
});

// Setting up random Notification
function randomNotification() {
  const randomItem = Math.floor(Math.random() * games.length);
  const notifTitle = games[randomItem].name;
  const notifBody = `Created by ${games[randomItem].author}.`;
  const notifImg = `img/${games[randomItem].slug}.jpg`;
  const options = {
    body: notifBody,
    icon: notifImg,
  };
  new Notification(notifTitle, options);
  setTimeout(randomNotification, 30000);
}

// Progressive loading images
const imagesToLoad = document.querySelectorAll('img[data-src]');
const loadImages = (image) => {
  image.setAttribute('src', image.getAttribute('data-src'));
  image.onload = () => {
    image.removeAttribute('data-src');
  };
};
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver((items) => {
    items.forEach((item) => {
      if (item.isIntersecting) {
        loadImages(item.target);
        observer.unobserve(item.target);
      }
    });
  });
  imagesToLoad.forEach((img) => {
    observer.observe(img);
  });
} else {
  imagesToLoad.forEach((img) => {
    loadImages(img);
  });
}
 