const footer = document.getElementById('footer');

footer.innerHTML = '<p>PRA - Juan Ramón Cárceles</p>';