# UOCFlix

Serverless app to check data about movies (votes, summaries, genres, date, images, etc.). All the data is fetched from The Movie Database REST API. It was developed with Vanilla JavaScript and it is a PWA (progressive web app) hence offering the possibility to be installed.

Developed as the final project for the Technologies and tools for web development course during my Master's degree. 