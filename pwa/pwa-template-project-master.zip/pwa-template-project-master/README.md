# PWA Template Project
A simple template project for PWAs with a service worker and caching.
