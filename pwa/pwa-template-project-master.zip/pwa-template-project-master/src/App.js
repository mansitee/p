function App()
{

}



App.prototype.start = function()
{
    
}