---
date: 2019-10-07T00:00:00-08:00
title: "Personal Articles"
description: "Discussing matters such as parenting, the trials and tribulations of autism, and a range of other hilarious personal topics."
sitemap:
  changefreq: "weekly"
  priority: 0.8
---

# 👨 Personal Articles

If life were simple. This is the nitty gritty of personal life. The challenges of parenting autistic kids, the trials of dealing with identical twins, the hilarious happenings that make life wonderful.

There is a specific RSS feed available for only items tagged with "Personal" available here: <a href="/data/tags/personal/index.xml" target="_blank">RSS feed</a>. Follow along on <a href='https://feedly.com/i/subscription/feed%2Fhttps%3A%2F%2Fjustinribeiro.com%2Fdata%2Ftags%2Fpersonal%2Findex.xml' target='blank'>Feedly</a>.