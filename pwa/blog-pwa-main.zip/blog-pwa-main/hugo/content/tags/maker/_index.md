---
date: 2019-10-07T00:00:00-08:00
title: "Maker, Builder, and Creativity Articles"
description: "All the maker projects and construction from Justin Ribeiro."
sitemap:
  changefreq: "weekly"
  priority: 0.8
---

# 🛠️ Maker, Builder, and Creativity Articles

Who doesn't love building things, whether it's a chicken coop, an indoor tree house, or just some random useful stuff?

There is a specific RSS feed available for only items tagged with "Maker" available here: <a href="/data/tags/maker/index.xml" target="_blank">RSS feed</a>. Follow along on <a href='https://feedly.com/i/subscription/feed%2Fhttps%3A%2F%2Fjustinribeiro.com%2Fdata%2Ftags%2Fimaker%2Findex.xml' target='blank'>Feedly</a>.