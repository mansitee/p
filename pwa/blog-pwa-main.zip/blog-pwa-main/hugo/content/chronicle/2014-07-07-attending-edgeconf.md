---
date: 2014-07-07T00:00:00Z
description: Push the web forward, one EdgeConf at a time.
title: Attending Edgeconf in September
url: /chronicle/2014/07/07/attending-edgeconf/
tags:
- Web
---

I'll be attending [Edgeconf in San Francisco](https://edgeconf.com/2014-sf) in September to talk about pushing the web forward. The lined up panels are stacked with a great amount of talented folks doing some great work and I'm looking forward to the debate format. I really enjoyed Edgeconf in New York last year (sadly, I wasn't able to attend Edge in London), and the installable panel I'm excited about.

Hope to see you there!