---
date: 2014-10-21T00:00:00Z
description: Hard work, hard interviews, and a lot of code later I'm a Google Developer Expert in Wearables!
title: And then I became a Google Developer Expert
url: /chronicle/2014/10/21/and-then-i-became-a-google-developer-expert/
tags:
- Business
---

Way back in late May I got an cheerful email from Alex over at Google explaining that someone had nominated me to become a Google Developer Expert for my work on Google Glass. I admit I was rather flattered; I had no idea I had made an impression on anyone.

Interviews, paperwork, meetings and other things later, I recently became stamped and minted: [Me @ Google Developer Experts](https://developers.google.com/experts/+JustinRibeiro). Specifically, I'm a GDE for 2014-2015 in Wearables.

What does this mean? Pretty much business as usual. I'll still be giving Helpouts, answering questions, giving talks, and releasing code samples and projects. I'm still doing Google Developer Group stuff, building out the Oakdale OpenMesh, and generally hacking on whatever I can get my hands on.

I will say this: thank you. To whomever nominated me, to the Googlers and GDE's who took the time to speak with me over the course of the process, to the people who pulled my name out of the hat way back when #ifihadglass was a hashtag. Thank you, now let's build some cool stuff!