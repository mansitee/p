---
date: 2015-03-16T00:00:00Z
description: A rundown of working with NFC on a few platforms for the NFC Forum
title: Guest post on Tap into NFC developer blog
url: /chronicle/2015/03/16/guest-post-tap-into-nfc/
tags:
- Web
- Business
- IoT
---

I've had the pleasure of speaking at NFC Forum event and hanging out at the booth to answer developer questions at AndDevCon last year. To add to helping developers understand a bit more about NFC, I've written a guest blog post of the NFC Forum's developer advocacy site, TapIntoNFC.org:

[Working with Android HCE, libNFC, and Chrome-NFC](http://tapintonfc.org/2015/03/working-with-androids-hce-libnfc-and-chrome-nfc/)

Many thanks to Lisa over at the NFC Forum for reaching out!