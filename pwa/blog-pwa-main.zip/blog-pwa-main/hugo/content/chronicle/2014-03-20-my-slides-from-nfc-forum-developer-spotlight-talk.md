---
tags:
- nfc
- talk
date: 2014-03-20T00:00:00Z
tags: []
title: My slides from NFC Forum Developer Spotlight talk
url: /chronicle/2014/03/20/my-slides-from-nfc-forum-developer-spotlight-talk/
---

Since I'm going to be running around at the [NFC Forum Developer Showcase event](http://nfc-forum.org/events/nfc-forum-developer-showcase/) tomorrow, here are the slides for my talk titled _[NFC and the web:
It’s happening](https://docs.google.com/presentation/d/1s-QRidCPcyaP8nuiYCuq1Ldr9LuaCLsQ5i11VrexSik/pub)_.

It's a short talk (no fancy crazy demo's or anything this time sorry), but if you want to learn a little bit about the NFC and what the web has to say about it then this is the talk for you.

Hope to see you there!