---
title: "My Kids Do Not Play That Sport and I Do Not Mind"
date: 2019-09-06T13:38:13-07:00
description: "My past experience playing a sport doesn't mean my kids have to follow suit, but you always as so now you get a think piece."
tags:
- Personal
- Kids
- Sports
---

It’s the beginning of the school year and inevitably I run into someone who remembers me. I say remembers, because it’s not that they know me today, but remember me from a time that I likely don’t recall (concussions will do that your memory). This will quickly turn into the following question:

“Why don’t your kids play soccer? You were a pretty good as I recall, don’t you want them to play?”

This is one of my most hated questions I get asked. Others include “can you fix my computer?” and “your job is easy, will you work just do this for free?”. That last question will land you on my go-fuck-yourself mailing list, a badge of shame that at least includes a choice holiday card.

This question however lands you onto a different list, a list of my-kids-shouldn’t-be-around-you variety. Parents who force their kids to play a sport that said parent likely participated in regardless of their personal skill or success within said sport, are to be eyed with suspicion.

“But my kid likes the sport.” No, they like your approval and are seeking it, often desperately.

“My kid is going to be a star.” No, they’re going to hang keep hanging their head as your scream at them from the sidelines.

The problem with so many parents is that they want to live vicariously through their child’s sporting success, a detriment to their child and probably anyone within their blast zone of screaming. This seems to be taken to all new extremes where people the same age as me to try to recapture their youth in new and odd ways, leading them to call me an “adult”, their air quotes so high in the air planes had to be diverted to another airport.

Yes, I am an adult. No, I will not follow you on Snapchat. Yes, I’ll coach your kids as long as you sit silently.

They never sit silently. They instead suck the fun out of a game, a game that kids are playing. It’s one reason I coach very little these days; I deal with enough hostility as it is without having to get threatened by parents in my off hours who think their kid is the next Ronoldo.

Inevitably, my reply is short and has none of the spirited and pointed view I maintain about the subject. “My kids don’t want to play soccer and I’m not one to make my kids play a sport they don’t enjoy.”

Which is one of the key takeaways I learned from my parents so long ago: if it isn’t fun, and you’re not enjoying it, why are you doing it? Too many miserable kids don’t have that option when it comes to sports.

My kids have that option. Maybe ask yourself if your kids should have the same option.
