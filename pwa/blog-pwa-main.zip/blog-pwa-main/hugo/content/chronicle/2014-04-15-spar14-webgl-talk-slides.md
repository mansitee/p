---
tags:
- webgl
- talk
date: 2014-04-15T00:00:00Z
title: My slides from SPAR International WebGL talk
url: /chronicle/2014/04/15/spar14-webgl-talk-slides/
---

Since I'm sitting at the airport and will be rather hectic tomorrow at [SPAR International](http://www.sparpointgroup.com/international/) tomorrow, here are the slides for my talk titled _[Beyond WebGL: increasing the online viewer performance pipeline on the web and for your audience](http://cdn.cache.stickmanventures.com/presentations/sparinternational2014/index.html#/)_.

Sadly, I had to reign the topic into something a bit more bitesized as requested (my original abstract was much deeper into the pipeline). That, and it's only a 30 minute talk; hard to fit the whole topic into there. It should be a fun talk nonetheless.

Hope to see you there!