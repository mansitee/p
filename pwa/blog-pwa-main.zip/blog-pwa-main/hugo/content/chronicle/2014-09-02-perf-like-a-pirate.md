---
date: 2014-09-02T00:00:00Z
description: Arggghhh, because web site performance is a priate matter.
title: Attending Perf like a Pirate at SFHTML5 this month
url: /chronicle/2014/09/02/perf-like-a-pirate/
tags:
- Web
---

In what is now apperantly becoming a tradition, [Perf Like a Pirate!](http://www.meetup.com/sfhtml5/events/199015882/) is headed back to SFHTML5 user group this month on September 19th. I missed last years event (see the piece from last year in which Colt McAnlis kills in his [Slay'n the Waste Monster](https://www.youtube.com/watch?v=RWmzxyMf2cE)), but since I'm in town for Edgeconf the next day I was not missing this event.

TO my knowledge, there are some slots still open if you want to attend (this year it's split between two web perf talks and two Android talks), so the night should have a little bit of something for every one.

Hope to see you there! If you can't make it, the [live stream will be up and running](https://www.youtube.com/watch?v=oP7at3rtLwk).