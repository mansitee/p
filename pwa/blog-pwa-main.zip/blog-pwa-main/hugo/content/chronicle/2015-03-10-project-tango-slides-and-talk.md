---
date: 2015-03-10T00:00:00Z
description: Slides from talk on developing for Project Tango
title: 'Developing for Project Tango: slides'
url: /chronicle/2015/03/10/project-tango-slides-and-talk/
tags:
- IoT
---

While not a secret, I haven't spoken much on working with Project Tango. A lot of the code I've worked in the last three months is still pretty raw, but exciting nonetheless. That excitment lead to a couple of talks this month to get people excited about developing for the platform; one at GDG Oakdale and one at GDG Fresno.

A copy of the slides are available: [https://goo.gl/chTreG](https://goo.gl/chTreG)

Many thanks to Larry Yang and the team from Project Tango for the correction on slide 32 (more eyes always better!). A shout out to Pacific mentor, GDG Fresno co-organizer, and all around good guy James Cha for inviting me to Fresno (great seeing everyone...DevFest 2015 is going to rock!).