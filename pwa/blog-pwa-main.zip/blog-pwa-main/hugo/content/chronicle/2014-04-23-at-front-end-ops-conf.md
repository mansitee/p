---
tags:
- frontend
- conference
date: 2014-04-23T00:00:00Z
title: At Front End Ops Conf Apr 24-25
url: /chronicle/2014/04/23/at-front-end-ops-conf/
---

Just a quick note to say I'll be roaming around the talks at [Front End Ops Conf 2014](http://www.feopsconf.com/) the next couple of days. There is an absolutely fabulous line up of speakers and it was just announced today they'll be live streaming so be sure to check the website starting tomorrow, April 24th, to see all the action.

Hope to see you there!