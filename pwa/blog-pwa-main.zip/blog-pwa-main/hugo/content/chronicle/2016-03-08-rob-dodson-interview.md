---
date: 2016-03-08T00:00:00Z
description: What is in store for Polymer in 2016? Rob Dodson sits down to discuss.
title: Interviewing Rob Dodson about Polymer roadmap 2016
tags:
- Web
---
I did a guest spot on the [Modern Web podcast](http://www.modern-web.org/#/modern-web-podcast) to interview the always awesome [Rob Dodson](https://twitter.com/rob_dodson) on the state of Polymer in 2016.

Many thanks to [Tracy Lee](https://twitter.com/ladyleet) for inviting me to do the interview. If you happen to be in or around Mountain View on March 16, she's holding a [great meetup on Polymer at Google](http://www.meetup.com/modernweb/events/228534464/) (I will be there!).