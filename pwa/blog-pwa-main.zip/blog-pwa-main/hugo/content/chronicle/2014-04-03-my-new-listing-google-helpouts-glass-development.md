---
tags:
- helpouts
- mirror-api
- google-glass
date: 2014-04-03T00:00:00Z
title: 'Now on Google Helpouts: Google Glass development'
url: /chronicle/2014/04/03/my-new-listing-google-helpouts-glass-development/
---

I recently was accepted to start offering Google Glass development help on Google's new Helpouts system. Right now, I'm not offering defined hours, but if you want to setup a time, just let me know.

[My Listing @ Google Hangouts](https://helpouts.google.com/106603156529760508714/ls/9605dd0ab4775b0e)