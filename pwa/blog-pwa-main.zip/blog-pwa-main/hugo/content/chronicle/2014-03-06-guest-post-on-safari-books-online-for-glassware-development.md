---
tags:
- google-glass
- writer
date: 2014-03-06T00:00:00Z
tags: []
title: Guest post on Safari Books Online for Glassware development
url: /chronicle/2014/03/06/guest-post-on-safari-books-online-for-glassware-development/
---

Back in the middle of Febuary, I was contacted by the folks who run Safari Books Online to write a series of guest blog posts on Google Glass development. The first of those articles was released yesturday, titled "[Building Glassware with the Mirror API](http://blog.safaribooksonline.com/2014/03/05/building-glassware-mirror-api/)".

I'm going to primarily focus on Mirror API development in the article series, namely because I find it fits 80% of use cases and is easier to get up and running for existing software implementations. I've used the Mirror API a lot and while I find the GDK quite nice to work with as well (I did use it for my talk demo last month) I continue to stick by the Mirror API. It's useful, powerful and since coming out into the API console for all in November, stable.