---
tags:
- google-glass
- writer
date: 2014-03-17T00:00:00Z
title: Second and third guest posts on Safari Books Online for Glassware development
  now live
url: /chronicle/2014/03/17/second-third-guest-posts-for-safari-books-online-glass-mirror-api-now-live/
---

Following up my [first piece](http://blog.safaribooksonline.com/2014/03/05/building-glassware-mirror-api/)) over at Safari Safari Books Online, my second article _[Using Subscriptions and Contacts on Google Glass](http://blog.safaribooksonline.com/2014/03/19/using-subscriptions-contacts-google-glass/)_ landed earlier this week. My [quick tip on handling lots of data on Glass](http://blog.safaribooksonline.com/2014/03/17/quick-tip-using-mirror-api-glass/) is also now available.

I found it very hard to work within a word limit for the articles; there is just so much good stuff to cover for the Mirror API. It's quite nice to work with in practice.