---
title: "Lacking Normal, Take Action"
description: "Nothing is easy in this pandemic, nothing is easy when grasping to old norms. Take action and let's improve our situation."
date: 2020-07-16T05:16:11-07:00
tags:
- personal
---
The knock on our collective door was one that we should have ignored. What started from soft taps finished with a pounding drone that left a fine powder from our walls. We knew not to open that door but for many patience grew short as did savings. The cure can’t be worse than the disease people said, and doors opened and people went back to their normal.

Normal came but not the normal of a time now long since forgotten. The normal of the virus was swift and unforgiving; infected cases rise to new heights daily as hospitals become overrun. Past experience tells us the dark fate of those confirmed cases will be an unrelenting death toll.

Better judgement was lost to falsehoods masquerading as facts, the dispelling of gibberish posing a deadly threat to person and community alike, our republic teetering on a knife's edge. The platforms shrug, beholden to shareholders and dystopian ideologies, touting their naive viewpoints on freedom of speech while people perish.

American exceptionalism has always been a fraught concept, overtaken with generalization and nationalist sound bites, and yet now we are the exception for all the wrong reasons. The pandemic consumes us, corruption defines our leaders who muster no plans and offer little in governance, standing idle watching the untimely deaths of black lives and frontline responders who are given no quarter from fates they do not deserve.

Take action. Put on a mask. Keep your distance. Stand up against systemic racism. Fight for a greater virtue that isn’t just for yourself, but that is for all. Otherwise, we fall as Rome did before us, into ashes.
