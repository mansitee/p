---
date: 2014-10-17T00:00:00Z
description: A list of resources from my talks at GDG DevFest Fresno.
title: Slides and materials for GDG DevFest Fresno
url: /chronicle/2014/10/17/slides-materials-gdg-devfest-fresno-2014/
tags:
- Web
- IoT
---

It's the night before [GDG DevFest Fresno 2014](http://devfest.gdgfresno.com) and I'm geared up and ready to roll. Some slides and materials you may want/need:

1. [My first talk: Google Glass: Introduction slides](https://www.justinribeiro.com/talks/google-glass-development-gdg-devfest-2014/)
2. [My second talk: Android Wear: Introduction slides](https://www.justinribeiro.com/talks/android-wear-introduction-gdg-devfest-2014/)
3. [Codelabs for Polymer @ It's Hackademic](http://www.itshackademic.com)

The event is going to be great, hope to see you there!