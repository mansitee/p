---
date: 2015-10-04T00:00:00Z
description: With a mix of old and new, audio never sounded so good.
title: Chromecast Audio and a 1970 Magnavox Astro Sonic stereo
url: /chronicle/2015/10/04/chromecast-audio-magnavox-astro-sonic-stereo/
tags:
- Maker
---

Monica and I have been hooking up every set of speakers we can to Chromecast Audio. The device has been a godsend in terms of just music everywhere and really complimenets our records and various other musical media (no one wants to take a record outside).

Case in point: Chromecast Audio hooked up to our 1970's era Magnavox Astro Sonic stereo sounds so sweet. Getting a little meta with the Who's Next record and the remastered playing through Cast.﻿

<img decoding="async" loading="lazy" width="800" height="538" style="background-size: cover;
          background-image: url('data:image/svg+xml;charset=utf-8,%3Csvg xmlns=\'http%3A//www.w3.org/2000/svg\' xmlns%3Axlink=\'http%3A//www.w3.org/1999/xlink\' viewBox=\'0 0 1280 853\'%3E%3Cfilter id=\'b\' color-interpolation-filters=\'sRGB\'%3E%3CfeGaussianBlur stdDeviation=\'.5\'%3E%3C/feGaussianBlur%3E%3CfeComponentTransfer%3E%3CfeFuncA type=\'discrete\' tableValues=\'1 1\'%3E%3C/feFuncA%3E%3C/feComponentTransfer%3E%3C/filter%3E%3Cimage filter=\'url(%23b)\' x=\'0\' y=\'0\' height=\'100%25\' width=\'100%25\' xlink%3Ahref=\'data%3Aimage/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAGCAIAAACepSOSAAAACXBIWXMAAC4jAAAuIwF4pT92AAAAs0lEQVQI1wGoAFf/AImSoJSer5yjs52ktp2luJuluKOpuJefsoCNowB+kKaOm66grL+krsCnsMGrt8m1u8mzt8OVoLIAhJqzjZ2tnLLLnLHJp7fNmpyjqbPCqLrRjqO7AIeUn5ultaWtt56msaSnroZyY4mBgLq7wY6TmwCRfk2Pf1uzm2WulV+xmV6rmGyQfFm3nWSBcEIAfm46jX1FkH5Djn5AmodGo49MopBLlIRBfG8yj/dfjF5frTUAAAAASUVORK5CYII=\'%3E%3C/image%3E%3C/svg%3E');" src="https://storage.googleapis.com/jdr-public-imgs/blog-archive/2015/10/20151004-DSCF4454.jpg" alt="Chromecast Audio hooked up to our 1970's era Magnavox Astro Sonic stereo">

