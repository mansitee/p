import '@justinribeiro/stl-part-viewer';
