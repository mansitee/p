# PWA App Shell - Work in progress

A Pen created on CodePen.io. Original URL: [https://codepen.io/mickaellarguier/pen/MNjqYV](https://codepen.io/mickaellarguier/pen/MNjqYV).

