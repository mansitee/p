document.addEventListener('click', function (event) {

	var menu = document.querySelector('.collapse');

	if ( !event.target.matches('.burger-menu') && !event.target.matches('.collapse') ) {
		if(menu.classList.contains('active')) {
			menu.classList.remove("active")
		}
		return;
	}

	console.log(event.target);
  
 	menu.classList.add('active');

}, false);