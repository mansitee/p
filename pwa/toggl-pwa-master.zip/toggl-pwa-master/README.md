# toggl-pwa
Toggl client as a Progressive Web App.
