# PWA-radio-streaming
This a simple model to apply in yours proyects <br>
Este es un simple modelo para que puedas aplicar en tus proyectos.

This has the manifest.json and the service worker in javascript<br>
Ya contiene el manifiesto y el servicio de trabajo en javascript

Feel free to use it ... all better is welcome<br>
Siente libre de Usarlo ... toda mejor es bienvenida

If you want give me a coffee, thanks ✌️😉<br>
Si quieres regalame un café, gracias 
☕ https://www.paypal.me/lurugardo
