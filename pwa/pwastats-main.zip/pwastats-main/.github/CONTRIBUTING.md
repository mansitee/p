## Contributing to PWAStats

Do you have a PWA-related blog post, video, presentation or case study that belongs on [pwastats.com](http://pwastats.com)? Then you should absolutely add it to the directory by following these steps:

1. Create a [new issue](https://github.com/cloudfour/pwastats/issues/new?title=Submission:+New+Story).
2. Fill out the submission template.
3. Be on the lookout for questions or comments.

Once the issue gets a "submission" label, it will be added shortly after.
