> **Note:** This template is for new case study content submissions only.
Feel free to replace the outline below if you are submitting a general issue instead.

---

### Summary

e.g. _XYZ Company saw a 20% decrease in its landing page bounce rate after introducing service worker caching._

### Source

e.g. http://example.com/2017/article

### Tags

- Tag 1
- Tag 2

_List all that apply from the [tags directory](https://github.com/cloudfour/pwastats/tree/master/_tags)._
