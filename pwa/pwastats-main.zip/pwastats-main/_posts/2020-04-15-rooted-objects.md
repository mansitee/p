---
title: Rooted Objects
sourceURL: https://aureatelabs.com/case-studies/rooted-objects-magento-2-pwa/
tags:
- Conversions
- E-commerce
- Fashion
- Performance
- Revenue
---

Fashion brand **Rooted Objects** saw an increase in conversions of **162%** after launching their PWA. Page load times decreased by **25%** and average redirection time decreased by **80%**.
