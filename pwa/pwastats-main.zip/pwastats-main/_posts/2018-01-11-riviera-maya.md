---
title: Grand Velas Riviera Maya
sourceURL: https://blog.milestoneinternet.com/industry-news/milestone-boosts-website-conversions-by-53-with-progressive-web-apps-pwa/
tags:
  - Conversions
  - Leisure
  - Home Screen
  - Notifications
  - Service Worker
  - Travel
---

**Grand Velas Riviera Maya** resort increased its Black Friday conversion rate by **53%** due to its progressive web app's speed and notifications.
