---
title: Raphael Hotel
sourceURL: http://www.prweb.com/releases/2017/07/prweb14501233.htm
tags:
- Conversions 
- Engagement 
- Service Worker
- Travel
---

**The Raphael Hotels'** new PWA increased website conversions by **20%**, pageviews by **66%**, sessions by **59%**, and reduced bounce rate **51%**.
