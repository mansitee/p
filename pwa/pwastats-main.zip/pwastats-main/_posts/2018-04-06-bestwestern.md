---
title: Best Western River North Hotel
sourceURL: https://www.hospitalitynet.org/news/4086888.html
tags:
  - Conversions
  - Home Screen
  - Offline
  - Service Worker
  - Travel
---

The **Best Western River North Hotel** sees **300%** increase in revenue with new Progressive Web App.
