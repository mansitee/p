---
title: Thomas Kent
sourceURL: https://www.vuestorefront.io/case-studies/thomas-kent
tags:
- E-commerce
- Revenue
- Performance
---

After launching its PWA, **Thomas Kent** lowered its bounce rate by **57%** and increased the revenue from organic traffic by **79%**.
