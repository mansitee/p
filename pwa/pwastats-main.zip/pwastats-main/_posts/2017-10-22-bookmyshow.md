---
title: BookMyShow
sourceURL: https://developers.google.com/web/showcase/2017/bookmyshow
tags:
- App Shell
- E-commerce
- Home Screen
- IndexedDB
- Leisure
- Notifications
- Service Worker
---

**BookMyShow**'s PWA takes less than **3** seconds to load and increased conversion rates over **80%**. The PWA is **54×** smaller than Android and **180×** smaller than iOS app.
