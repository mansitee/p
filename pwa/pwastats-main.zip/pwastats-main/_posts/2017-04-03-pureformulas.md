---
title: PureFormulas
sourceURL: https://www.mobify.com/customers/pureformulas/
tags:
  - Health
  - Home Screen
  - Notifications
  - Payment
  - Service Worker
  - Offline
---

**PureFormulas**' PWA saw **23%** higher revenue than the m.dot website it 
replaced.
