---
title: Jumia Travel
sourceURL: https://developers.google.com/web/showcase/2017/jumia
tags:
  - App Shell
  - IndexedDB
  - Notifications
  - Offline
  - Service Worker
  - Travel
---

**Jumia Travel**'s PWA has **12×** more users compared to its native apps and uses **80%** less data. Since launch, the PWA has **33%** higher conversion and **50%** lower bounce rate.
