---
title: BookMyShow
sourceURL: http://tech.economictimes.indiatimes.com/news/mobile/bookmyshow-revamps-its-mobile-site-as-a-progressive-web-app/58926776
tags:
  - App Shell
  - E-commerce
  - Home Screen
  - IndexedDB
  - Leisure
  - Notifications
  - Service Worker
---

**BookMyShow** witnessed over **80%** increase in conversion and a dramatic increase in revenue after launching its PWA.
