---
title: The Weather Channel
sourceURL: https://developers.google.com/web/showcase/2016/weather-channel
tags:
  - News
  - Notifications
  - Service Worker
  - Offline
---

**The Weather Channel** saw an **80%** improvement in load time after shipping
Progressive Web Apps in 62 languages to 178 countries.
