---
title: Twitter Lite
sourceURL: https://blog.twitter.com/2017/how-we-built-twitter-lite
tags:
  - App Shell
  - Home Screen
  - IndexedDB
  - Notifications
  - Offline
  - Service Worker
  - Social
---

**Twitter Lite** is interactive in less than **5** seconds over 3G on most
devices, with average load times reduced by over **30%**.
