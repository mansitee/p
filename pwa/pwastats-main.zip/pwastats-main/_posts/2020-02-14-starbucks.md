---
title: Starbucks
sourceURL: https://twitter.com/davidbrunelle/status/993960071406080000?ref_src=twsrc%5Etfw

tags:
  - Conversions
  - E-commerce
  - Performance
  - Service Worker
---

 The **Starbucks** PWA has increased daily active users **2×**. Orders on desktop are nearly the same rate as mobile.