---
title: Debenhams
sourceURL: https://www.thinkwithgoogle.com/intl/en-gb/success-stories/global-success-stories/debenhams-progressive-web-app-boosts-speed-conversions-and-revenue/
tags:
  - Conversions
  - E-commerce
  - Performance
  - Revenue
  - Service Worker
---

**Debenhams** found that the user journey from browsing to purchase was **2×** to **4×** on its PWA. The PWA delivered a **40%** increase in mobile revenue and a **20%** increase in conversion.