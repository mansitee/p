---
title: MakeMyTrip.com
sourceURL: https://developers.google.com/web/showcase/2017/make-my-trip
tags:
  - E-commerce
  - Home Screen
  - Notifications
  - Travel
  - Service Worker
---

**MakeMyTrip's** PWA saw a **3×** increase in conversion and **160%** increase in shopper sessions. Pages are **38%** faster. First-time shoppers are **3×** more likely to convert on the PWA than in native app.
