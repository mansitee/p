---
title: Butcher of Blue
sourceURL: https://www.vuestorefront.io/case-studies/butcher-of-blue
tags:
- Conversions
- E-commerce
- Fashion
- Performance
---

**Butcher of Blue**'s PWA increased mobile users by **154%**, monthly active users by **154%**, and conversion by **169%**. Pages load **85%** faster.