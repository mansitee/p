---
title: AliExpress
sourceURL: https://developers.google.com/web/showcase/2016/aliexpress
tags:
  - E-commerce
  - Offline
---

**AliExpress** improved conversion rate for new users by **104%** across all
browsers, with **2×** more pages visited and **74%** more time spent per 
session.
