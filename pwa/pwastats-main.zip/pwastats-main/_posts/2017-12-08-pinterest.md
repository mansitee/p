---
title: Pinterest
sourceURL: https://medium.com/dev-channel/a-pinterest-progressive-web-app-performance-case-study-3bd6ed2e6154
tags:
 - Conversions
 - Engagement
 - App Shell
 - Service Worker
 - Offline
 - Social
---

**Pinterest** rebuilt their mobile site as a PWA and core engagements increase by **60%**. They also saw a **44%** increase in user-generated ad revenue and time spent on the site has increased by **40%**.
