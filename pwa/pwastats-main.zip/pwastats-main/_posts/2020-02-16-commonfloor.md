---
title: Commonfloor
sourceURL: https://medium.com/awebdeveloper/pwa-is-future-of-mobile-how-to-tame-it-855dd42df0ec
tags:
- App Shell
- E-commerce
- Performance
- Social
---

**Commonfloor** groups saw **2×** increase in daily active users and a **10%** increase in overall traffic by moving to a PWA with app shell.