# digital-library-pwa
Template for digital library progressive web app (PWA)... It is live at [SchultzPWA](https://www.jasonclark.info/files/digital-library-pwa/).

## Technology

* HTML
* CSS
* Javascript
* PWA requirements: Manifest, ServiceWorker

## People

Crafted with :heart: by [Jason A. Clark](http://www.jasonclark.info) sameAs [@jaclark](https://twitter.com/jaclark)
