# Contoh Aplikasi PWA

Membangun aplikasi Web dan PWA dari awal. Aplikasi sederhana untuk melakukan acak warna hex. Menggunakan HTML, CSS dan JavaScript tanpa framework dan library.

Beberapa topik pembahasan:
* [x] Pembuatan aplikasi dengan HTML, CSS dan JavaScript
* [x] Pembuatan web app manifest
* [ ] Audit dengan alat bantu lighthouse
* [ ] Menggunakan Service Worker
* dan lain-lain

Versi live dapat dilihat di [https://warna-favorit-pwa.web.app/](https://warna-favorit-pwa.web.app/)

Dikembangkan untuk keperluan pembelajaran dan dibahas di sesi livestreaming [youtube.com/rizafahmi](https://youtube.com/rizafahmi).
