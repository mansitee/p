# radio-pwa
Radio en streaming - Se puede instalar como aplicacion PWA en móviles y tablets

Captura de pantalla (funcionando en móvil)

![Captura de pantalla](https://github.com/luisgulo/radio-pwa/blob/master/screenshot/aplicacion-en-movil.png?raw=true)
