/* global zuix */
'use strict';
zuix.controller(function(cp){
    cp.create = function() {
        // TODO: handle input
    };
});
