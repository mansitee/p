## We are creating a new version

Check the [codelab available here](https://pwafire.org/developer/codelabs/get-started-with-pwafireapp/) to use the previous version of the sample app
