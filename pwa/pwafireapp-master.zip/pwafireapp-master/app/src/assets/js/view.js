 // Display data into our web app
 const article_title=document.querySelector("#article_title");
 const article_caption=document.querySelector("#article_caption");
