# Mikmoni Hotspot Template

> Panduan konfigurasi disertakan dalam file readme masing-masing template.

**Cara Download:**

<p align="center">
<img src="https://raw.githubusercontent.com/renomureza/mikmoni-hotspot-template/master/cara-download.png" />
</p>

1. Klik tombol **Code** di atas.
2. Pilih **Download ZIP**.

atau, download langsung melalui link berikut: **[DOWNLOAD](https://github.com/renomureza/mikmoni-hotspot-template/archive/refs/heads/master.zip)**

Cara ini akan mengunduh semua template.

## [Monipel](https://github.com/renomureza/mikmoni-hotspot-template/tree/master/monipel)

<p align="center">
<img src="https://raw.githubusercontent.com/renomureza/mikmoni-hotspot-template/master/monipel.png" />
</p>

## [Ramadhan](https://github.com/renomureza/mikmoni-hotspot-template/tree/master/ramadhan)

<p align="center">
<img src="https://raw.githubusercontent.com/renomureza/mikmoni-hotspot-template/master/ramadhan.png" />
</p>
