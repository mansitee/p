<?php
echo <<<END
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <title>LOGIN</title>
    <link rel="icon" type="image/png" href="assets/img/favicon.png" sizes="32x32">
    <link rel="stylesheet" href="assets/css/style.css">
	<script>
    //redirect user EXPIRED
    var error  = "$(error)";
    if(error == "Pengguna $(username) telah mencapai batas waktu"){
	window.location.href = "./isolir.html";
    } else if(error == "Pengguna $(username) telah mencapai batas traffic"){
	window.location.href = "./isolir-kuota.html";
	}
	</script>
</head>

<body>
	       <form action='$loginpath' method='post' name='Login_Form' class='form-signin'>
            <input type='hidden' name='challenge' value='$challenge'>
            <input type='hidden' name='uamip' value='$uamip'>
            <input type='hidden' name='uamport' value='$uamport'>
		<input type="hidden" name="popup" value="true" />
	</form>
	
	<script type="text/javascript" src="/md5.js"></script>
	<script type="text/javascript">
		function doLogin() {
			document.sendin.username.value = document.login.username.value;
			document.sendin.password.value = hexMD5('$(chap-id)' + document.login.password.value +
			'$(chap-challenge)');
			document.sendin.submit();
			return false;
		}
	</script>

    <!-- App Header -->
    <div class="appHeader bg-primary text-light">		
		<div class="left"><div class="headerButton">
            <div class="form-check form-switch">
                <input class="form-check-input dark-mode-switch" type="checkbox" id="darkmodeSwitch">
                <label class="form-check-label" for="darkmodeSwitch"></label>
            </div>
        </div></div>
		<div class="pageTitle">
            <img src="assets/img/logo-icon.png" alt="logo" class="logo"> <script src="assets/config/namawifi.js"></script>
        </div>
        <div class="right">
            <a href="#" class="headerButton" data-bs-toggle="modal" data-bs-target="#Notif">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
				<path fill="#ffffff" d="M10 21H14C14 22.1 13.1 23 12 23S10 22.1 10 21M21 19V20H3V19L5 17V11C5 7.9 7 5.2 10 4.3V4C10 2.9 10.9 2 12 2S14 2.9 14 4V4.3C17 5.2 19 7.9 19 11V17L21 19M17 11C17 8.2 14.8 6 12 6S7 8.2 7 11V18H17V11Z" />
				</svg>
                <span class="badge badge-danger">1</span>
            </a>
        </div>

    </div>
    <!-- * App Header -->
	
	<!-- Notifikasi -->
        <div class="modal fade dialogbox" id="Notif" data-bs-backdrop="static" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-icon">
						<div class="avatar-section">
							<a href="#">
								<img src="assets/img/favicon.png" alt="avatar" class="imaged w100 rounded">
								<span class="button btn-success">
									<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
									<path fill="#ffffff" d="M10,17L6,13L7.41,11.59L10,14.17L16.59,7.58L18,9M12,1L3,5V11C3,16.55 6.84,21.74 12,23C17.16,21.74 21,16.55 21,11V5L12,1Z" />
									</svg>
								</span>
							</a>
						</div>
                    </div>
                    <div class="modal-header">
                        <h5 class="modal-title"><script src="assets/config/namawifi.js"></script></h5>
                    </div>
                    <div class="modal-body">
                        <script src="assets/config/informasi.js"></script>
                    </div>
                    <div class="modal-footer">
                        <div class="btn-inline">
                            <a href="#" class="btn btn-text-primary" data-bs-dismiss="modal">TUTUP</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <!-- * Notifikasi -->

    <!-- App Capsule -->
    <div id="appCapsule">
	
			<div class="section wallet-card-section full pt-1">
				<!-- SLIDER carousel single -->
					<div class="carousel-single splide">
						<div class="splide__track">
							<ul class="splide__list">
							<!-- gambar slider awal -->
								<li class="splide__slide">
									<div class="card-main">
										<div class="section full">
											<a href="bantuan.html"><img src="assets/img/sample/slide/slide1.png" alt="image" class="card-block w-100"></a>
										</div>
									</div>
								</li>
							<!-- *akhir gambar slider -->
							<!-- gambar slider awal -->
								<li class="splide__slide">
									<div class="card-main">
										<div class="section full">
											<img src="assets/img/sample/slide/slide2.png" alt="image" class="card-block w-100">
										</div>
									</div>
								</li>
							<!-- *akhir gambar slider -->
							<!-- gambar slider awal -->
								<li class="splide__slide">
									<div class="card-main">
										<div class="section full">
											<img src="assets/img/sample/slide/slide3.png" alt="image" class="card-block w-100">
										</div>
									</div>
								</li>
							<!-- *akhir gambar slider -->
							</ul>
						</div>
					</div>
				<!-- * SLIDER carousel single -->
			</div>

        <!-- Template Login -->
        <div class="section mt-2">
            <div class="wallet-card">
                <!-- Formulir Login -->
                            <form action='$loginpath' method='post' name='Login_Form'>
            <input type='hidden' name='challenge' value='$challenge'>
            <input type='hidden' name='uamip' value='$uamip'>
            <input type='hidden' name='uamport' value='$uamport'>
            <input type='hidden' name='userurl' value='$userurl'>
                                <div class="form-group basic">
                                    <div class="input-wrapper">
                                        <label class="label" for="username">Masukan Voucher</label>

										    <input type='text' id='idusr' class='$center form-control' name='UserName' placeholder='Masukan Kode Voucher' required='''/>

										    <input type='hidden' id='pass' class='$center form-control' name='Password' placeholder='Masukan Password Member' required=''/>
            <input type='hidden' name='button'  value='Login'>
<!-- =========GANTI TRIAL DISINI BRO======= -->
 <script>
            function change() {
                var idusr = document.getElementById('idusr').value = 'Trial';
            }
        </script>

                                        <i class="clear-input">
                                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
											<path fill="#FFFFFF" d="M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2C6.47,2 2,6.47 2,12C2,17.53 6.47,22 12,22C17.53,22 22,17.53 22,12C22,6.47 17.53,2 12,2M14.59,8L12,10.59L9.41,8L8,9.41L10.59,12L8,14.59L9.41,16L12,13.41L14.59,16L16,14.59L13.41,12L16,9.41L14.59,8Z" />
											</svg>
                                        </i>
                                    </div>
                                </div>
                                <div class="form-group basic">
								 <button class=' btn btn-primary btn-block btn-lg' onClick='\'javascript:popUp('$loginpath?res=popup1&uamip=$uamip&uamport=$uamport')\'> LOGIN </button>
<br>


            </div>
            <center><form action='$loginpath' method='post' name='Login_Form'>
            <input type='hidden' name='challenge' value='$challenge'>
            <input type='hidden' name='uamip' value='$uamip'>
            <input type='hidden' name='uamport' value='$uamport'>
            <input type='hidden' name='userurl' value='$userurl'>

</script>
<br>

</b>


                <!-- * Balance -->
                <!-- Wallet Footer -->
                <div class="wallet-footer">
                <div class="item">
                            <div class="">
                        <button class='icon-wrapper bg-danger'onClick='change()'><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
								<path fill="#ffffff" d="M15,14C12.33,14 7,15.33 7,18V20H23V18C23,15.33 17.67,14 15,14M6,10V7H4V10H1V12H4V15H6V12H9V10M15,12A4,4 0 0,0 19,8A4,4 0 0,0 15,4A4,4 0 0,0 11,8A4,4 0 0,0 15,12Z" />
								</svg>
							</div>
                            <strong><b>COBA<br>GRATIS</b></strong>
                        </a>
                    </div>
                           </script>
<div class="item">
<div class="">
            <button class='icon-wrapper'onClick='togglePasswordVisibility()'><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
								<path fill="#ffffff" d="M10 12C12.21 12 14 10.21 14 8S12.21 4 10 4 6 5.79 6 8 7.79 12 10 12M10 6C11.11 6 12 6.9 12 8S11.11 10 10 10 8 9.11 8 8 8.9 6 10 6M12 20H2V17C2 14.33 7.33 13 10 13C10.91 13 12.13 13.16 13.35 13.47C13.26 13.8 13.2 14.15 13.2 14.5V15.39C12.22 15.1 11.1 14.9 10 14.9C7.03 14.9 3.9 16.36 3.9 17V18.1H12C12 18.13 12 18.17 12 18.2V20M20.8 17H16.5V14.5C16.5 13.7 17.2 13.2 18 13.2S19.5 13.7 19.5 14.5V15H20.8V14.5C20.8 13.1 19.4 12 18 12S15.2 13.1 15.2 14.5V17C14.6 17 14 17.6 14 18.2V21.7C14 22.4 14.6 23 15.2 23H20.7C21.4 23 22 22.4 22 21.8V18.3C22 17.6 21.4 17 20.8 17Z" />
								</svg>
								
								
							</div>
                            <strong>LOGIN<br>MEMBER</strong>
                            
                        

                        </a>
                    </div>
                    <div class="item">
                        <a href="faq.html">
                            <div class="icon-wrapper bg-success">
                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
								<path fill="#ffffff" d="M13,8A4,4 0 0,1 9,12A4,4 0 0,1 5,8A4,4 0 0,1 9,4A4,4 0 0,1 13,8M17,18V20H1V18C1,15.79 4.58,14 9,14C13.42,14 17,15.79 17,18M20.5,14.5V16H19V14.5H20.5M18.5,9.5H17V9A3,3 0 0,1 20,6A3,3 0 0,1 23,9C23,9.97 22.5,10.88 21.71,11.41L21.41,11.6C20.84,12 20.5,12.61 20.5,13.3V13.5H19V13.3C19,12.11 19.6,11 20.59,10.35L20.88,10.16C21.27,9.9 21.5,9.47 21.5,9A1.5,1.5 0 0,0 20,7.5A1.5,1.5 0 0,0 18.5,9V9.5Z" />
								</svg>
							</div>
                            <strong>BUTUH<br>BANTUAN</strong>
                        </a>
                    </div>
					<div class="item">
                      <a href="pembayaran.html">
                            <div class="icon-wrapper bg-warning">
                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
								   <path fill="#ffffff" d="M7 4C4.8 4 3 5.8 3 8S4.8 12 7 12 11 10.2 11 8 9.2 4 7 4M7 10C5.9 10 5 9.1 5 8S5.9 6 7 6 9 6.9 9 8 8.1 10 7 10M7 14C3.1 14 0 15.8 0 18V20H11V18H2C2 17.4 3.8 16 7 16C8.8 16 10.2 16.5 11 17V14.8C9.9 14.3 8.5 14 7 14M22 4H15C13.9 4 13 4.9 13 6V18C13 19.1 13.9 20 15 20H22C23.1 20 24 19.1 24 18V6C24 4.9 23.1 4 22 4M16 18H15V6H16V18M22 18H18V6H22V18Z" />
								</svg>
							</div>
                            <strong>TRANSAKSI<br>VIA QRIS</strong>
                        </a>
                    </div>

                </div>
                <!-- * Wallet Footer -->

        <!-- Produk Paket -->
        <div class="section full mt-2">
            <!-- batas atas slide produk -->
            <div class="carousel-small splide">
                <div class="splide__track">
                    <ul class="splide__list">
            <!-- list produk -->
                        <li class="splide__slide">
                            <a href="#">
                                <div class="user-card">
                                    <img src="assets/img/sample/produk/produk1.png" alt="img" class="imaged w-100">
                                    <strong>Paket 5Jam</strong>
									<strong>
										<a href="pembayaran.html" class="btn btn-primary btn-block btn-sm">
											Rp 3.000
										</a>
									</strong>
                                </div>
                            </a>
                        </li>
            <!-- * batas list produk -->
            <!--  list produk -->
                        <li class="splide__slide">
                            <a href="#">
                                <div class="user-card">
                                    <img src="assets/img/sample/produk/produk1.png" alt="img" class="imaged w-100">
                                    <strong>Paket 7Hari</strong>
									<strong>
										<a href="pembayaran.html" class="btn btn-primary btn-block btn-sm">
											Rp 25.000
										</a>
									</strong>
                                </div>
                            </a>
                        </li>
            <!-- * batas list produk -->
            <!--  list produk -->
                        <li class="splide__slide">
                            <a href="#">
                                <div class="user-card">
                                    <img src="assets/img/sample/produk/produk1.png" alt="img" class="imaged w-100">
                                    <strong>Paket 30Hari</strong>
									<strong>
										<a href="pembayaran.html" class="btn btn-primary btn-block btn-sm">
											Rp 65.000
										</a>
									</strong>
                                </div>
                            </a>
                        </li>
            <!-- * batas list produk -->
            <!--  list produk -->
                        <li class="splide__slide">
                            <a href="#">
                                <div class="user-card">
                                    <img src="assets/img/sample/produk/produk1.png" alt="img" class="imaged w-100">
                                    <strong>Paket Ngebut</strong>
									<strong>
										<a href="pembayaran.html" class="btn btn-primary btn-block btn-sm">
											Rp 75.000
										</a>
									</strong>
                                </div>
                            </a>
                        </li>
            <!-- * batas list produk -->
                    </ul>
                </div>
            </div>
            <!-- * batas bawah slide produk -->
        </div>
        <!-- * Produk Paket -->

        <!-- Paket Lainnya -->
        <div class="section full mt-2 mb-1">
        </div>
        <!-- * Paket Lainnya -->

        <!-- app footer -->
        <div class="appFooter">
            <div class="footer-title">
                Support by <script src="assets/config/supported.js"></script>
            </div>
            © Design by <a href="https://www.bdr.my.id"><script src="assets/config/namawifi.js"></script></a>
        </div>
        <!-- * app footer -->

    </div>
    <!-- * App Capsule -->


    <!-- Menu Bawah -->
    <div class="appBottomMenu">
        <a href="#" class="item active">
            <div class="col">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
				<path fill="#6236FF" d="M17 14H19V17H22V19H19V22H17V19H14V17H17V14M5 20V12H2L12 3L22 12H17V10.19L12 5.69L7 10.19V18H12C12 18.7 12.12 19.37 12.34 20H5Z" />
				</svg>
				<strong>Beranda</strong>
            </div>
        </a>
		<a href="https://laksa19.github.io/myqr/" class="item">
            <div class="col">
                <div class="action-button large">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
				<path fill="#ffffff" d="M4,4H10V10H4V4M20,4V10H14V4H20M14,15H16V13H14V11H16V13H18V11H20V13H18V15H20V18H18V20H16V18H13V20H11V16H14V15M16,15V18H18V15H16M4,20V14H10V20H4M6,6V8H8V6H6M16,6V8H18V6H16M6,16V18H8V16H6M4,11H6V13H4V11M9,11H13V15H11V13H9V11M11,6H13V10H11V6M2,2V6H0V2A2,2 0 0,1 2,0H6V2H2M22,0A2,2 0 0,1 24,2V6H22V2H18V0H22M2,18V22H6V24H2A2,2 0 0,1 0,22V18H2M22,22V18H24V22A2,2 0 0,1 22,24H18V22H22Z" />
				</svg>
                </div>
            </div>
        </a>
        <a href="bantuan.html" class="item">
            <div class="col">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
				<path fill="#6236FF" d="M13,8A4,4 0 0,1 9,12A4,4 0 0,1 5,8A4,4 0 0,1 9,4A4,4 0 0,1 13,8M17,18V20H1V18C1,15.79 4.58,14 9,14C13.42,14 17,15.79 17,18M20.5,14.5V16H19V14.5H20.5M18.5,9.5H17V9A3,3 0 0,1 20,6A3,3 0 0,1 23,9C23,9.97 22.5,10.88 21.71,11.41L21.41,11.6C20.84,12 20.5,12.61 20.5,13.3V13.5H19V13.3C19,12.11 19.6,11 20.59,10.35L20.88,10.16C21.27,9.9 21.5,9.47 21.5,9A1.5,1.5 0 0,0 20,7.5A1.5,1.5 0 0,0 18.5,9V9.5Z" />
				</svg>	
				<strong>Bantuan</strong>
            </div>
        </a>
    </div>
    <!-- * Menu Bawah -->

	<!-- Script Tambahan -->
    <script type="text/javascript">
        var username = document.login.username;
        var password = document.login.password;

        function setpass() {
            var user = username.value
            password.value = user;
            console.log(user);
        }
        username.onchange = setpass;
    </script>
	<!-- Script Tambahan -->

  <!-- ========= JS Files =========  -->
    <!-- Bootstrap -->
    <script src="assets/js/lib/bootstrap.bundle.min.js"></script>
    <!-- Base Js File -->
    <script src="assets/js/base.js"></script>
    <!-- Splide -->
    <script src="assets/js/plugins/splide/splide.min.js"></script>
        <script>
            function change() {
                var idusr = document.getElementById('user').value = 'TRIAL';
                var idpsw = document.getElementById('pass').value = 'TRIAL';
            }
        </script>
            <span class='password-toggle-icon' onclick='togglePasswordVisibility()'>
</span>
</div>
<style>
  .password-toggle-icon {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-10%);
    width: 60px;
    height: 60px;
    background-image: url('/hotspotlogin/template/rgb/img/mata.gif');
    background-repeat: no-repeat;
    background-size: contain;
    cursor: pointer;
  }
  .password-toggle-icon.active {
    background-image: url('/hotspotlogin/template/rby/img/mata.gif');
  }
</style>
<script>
  function togglePasswordVisibility() {
    var passwordInput = document.getElementById('pass');
    var passwordIcon = document.querySelector('.password-toggle-icon');

    if (passwordInput.getAttribute('type') == 'password') {
      passwordInput.setAttribute('type', 'text');
      passwordIcon.classList.add('active');
    } else {
      passwordInput.setAttribute('type', 'password');
      passwordIcon.classList.remove('active');
    }
  }


</script>

</body>

</html>


END;


?>
