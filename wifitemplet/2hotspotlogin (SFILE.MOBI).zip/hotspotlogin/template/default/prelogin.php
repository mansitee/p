<!doctype html>
<html lang="en">

<head>
	<meta http-equiv="refresh" content="5; url=http://10.1.0.1:3990/logoff">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <title>LOGOUT</title>
    <link rel="icon" type="image/png" href="assets/img/favicon.png" sizes="32x32">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body class="bg-white">

    <!-- App Header -->
    <div class="appHeader no-border">
        <div class="left">
            <a href=\"http://10.1.0.1:3990/logoff\" class="headerButton">
				<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="36" height="36" viewBox="0 0 24 24">
				<path fill="#6236FF" d="M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z" />
				</svg>
            </a>
        </div>
        <div class="pageTitle">
            Logout
        </div>
        <div class="right">
        </div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule">

        <div class="section">
            <div class="splash-page mt-5 mb-5">
                    <div class="modal-icon">
						<div class="avatar-section">
							<a href="#">
								<img src="assets/img/favicon.png" alt="avatar" class="imaged w100 rounded">
								<span class="button btn-warning">
									<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
									<path fill="#ffffff" d="M12 1L3 5V11C3 16.5 6.8 21.7 12 23C17.2 21.7 21 16.5 21 11V5L12 1M16 15.8C16 16.4 15.4 17 14.7 17H9.2C8.6 17 8 16.4 8 15.7V12.2C8 11.6 8.6 11 9.2 11V8.5C9.2 7.1 10.6 6 12 6S14.8 7.1 14.8 8.5V9H13.5V8.5C13.5 7.7 12.8 7.2 12 7.2S10.5 7.7 10.5 8.5V11H14.8C15.4 11 16 11.6 16 12.3V15.8Z" />
									</svg>
								</span>
							</a>
						</div>
                    </div>
				<br/>
                <h2 class="mb-2">OpenWrt</h2>
                <p>
                    Anda telah keluar dari jaringan <a href="#"><script src="assets/config/namawifi.js"></script></a><br/>Terimakasih sudah menggunakan layanan kami.
                </p>
            </div>
        </div>

        <div class="fixed-bar">
                <div class="form-button-group  transparent">
                    <a href="http://10.1.0.1:3990/logoff\" type="button" class="btn btn-primary btn-block btn-lg">Login Kembali</a>
                </div>
        </div>

    </div>
    <!-- * App Capsule -->


    <!-- ========= JS Files =========  -->
    <!-- Bootstrap -->
    <script src="assets/js/lib/bootstrap.bundle.min.js"></script>
    <!-- Base Js File -->
    <script src="assets/js/base.js"></script>


</body>

</html>