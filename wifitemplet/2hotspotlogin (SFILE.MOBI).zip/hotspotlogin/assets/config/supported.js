document.write('Coffee Hotspot')
//Sesuaikan
//Jangan Menghapus kode scriptnya