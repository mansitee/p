<?php
/*
 */

echo "<div class='container-fluid'><div class='alert-wrapper  text-center'>";

echo "<div class='alert alert-primary text-center' role='alert'>
    $h1Loggedout";
echo "</div>";
echo "<br>";
echo "<a class='btn btn-success' href=\"http://$uamip:$uamport/prelogin\" role='button'>$centerLogin</a>";
echo "</div></div>";
