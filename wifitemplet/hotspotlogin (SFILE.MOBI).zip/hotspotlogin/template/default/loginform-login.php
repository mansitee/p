<?php
echo <<<END
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <title>LOGIN</title>
    <link rel="icon" type="image/png" href="assets/img/favicon.png" sizes="32x32">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
       <form action='$loginpath' method='post' name='Login_Form' class='form-signin'>
            <input type='hidden' name='challenge' value='$challenge'>
            <input type='hidden' name='uamip' value='$uamip'>
            <input type='hidden' name='uamport' value='$uamport'>
		<input type="hidden" name="popup" value="true" />
	</form>

    <!-- App Header -->
    <div class="appHeader bg-primary text-light">		
		<div class="left"><div class="headerButton">
            <div class="form-check form-switch">
                <input class="form-check-input dark-mode-switch" type="checkbox" id="darkmodeSwitch">
                <label class="form-check-label" for="darkmodeSwitch"></label>
            </div>
        </div></div>
		<div class="pageTitle">
            <img src="assets/img/logo-icon.png" alt="logo" class="logo"> <script src="assets/config/namawifi.js"></script>
        </div>
        <div class="right">
            <a href="#" class="headerButton" data-bs-toggle="modal" data-bs-target="#DialogIconedInfo">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
				<path fill="#ffffff" d="M10 21H14C14 22.1 13.1 23 12 23S10 22.1 10 21M21 19V20H3V19L5 17V11C5 7.9 7 5.2 10 4.3V4C10 2.9 10.9 2 12 2S14 2.9 14 4V4.3C17 5.2 19 7.9 19 11V17L21 19M17 11C17 8.2 14.8 6 12 6S7 8.2 7 11V18H17V11Z" />
				</svg>
                <span class="badge badge-danger">1</span>
            </a>
        </div>

    </div>
    <!-- * App Header -->
	
	<!-- DialogIconedInfo -->
        <div class="modal fade dialogbox" id="DialogIconedInfo" data-bs-backdrop="static" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="48" height="48" viewBox="0 0 24 24">
						<path fill="#6236FF" d="M12 12C9.97 12 8.1 12.67 6.6 13.8L4.8 11.4C6.81 9.89 9.3 9 12 9S17.19 9.89 19.2 11.4L17.92 13.1C17.55 13.17 17.18 13.27 16.84 13.41C15.44 12.5 13.78 12 12 12M21 9L22.8 6.6C19.79 4.34 16.05 3 12 3S4.21 4.34 1.2 6.6L3 9C5.5 7.12 8.62 6 12 6S18.5 7.12 21 9M12 15C10.65 15 9.4 15.45 8.4 16.2L12 21L13.04 19.61C13 19.41 13 19.21 13 19C13 17.66 13.44 16.43 14.19 15.43C13.5 15.16 12.77 15 12 15M17.75 19.43L16.16 17.84L15 19L17.75 22L22.5 17.25L21.34 15.84L17.75 19.43Z" />
						</svg>
                    </div>
                    <div class="modal-header">
                        <h5 class="modal-title"><script src="assets/config/namawifi.js"></script></h5>
                    </div>
                    <div class="modal-body">
                        Gunakan internet dengan bijak!!!
                    </div>
                    <div class="modal-footer">
                        <div class="btn-inline">
                            <a href="#" class="btn" data-bs-dismiss="modal">OKE</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <!-- * DialogIconedInfo -->


    <!-- App Capsule -->
    <div id="appCapsule">

        <!-- Wallet Card -->
        <div class="section wallet-card-section pt-1">
            <div class="wallet-card">
                <!-- Balance -->

<font color='#6104FF'><center><b><script type='text/javascript'>
			<!--
			var months = ['JANUARI', 'FERBUARI', 'MARET', 'APRIL', 'MEI', 'JUNI', 'JULI', 'AGUSTUS', 'SEPTEMBER', 'OKTOBER', 'NOVEMBER', 'DESEMBER'];
			var myDays = ['MINGGU', 'SENIN', 'SELASA', 'RABU', 'KAMIS', 'JUM&#39; AT', 'SABTU'];
			var date = new Date();
			var day = date.getDate();
			var month = date.getMonth();
			var thisDay = date.getDay(),
			    thisDay = myDays[thisDay];
			var yy = date.getYear();
			var year = (yy < 1000) ? yy + 1900 : yy;
			document.write(thisDay + ', ' + day + ' ' + months[month] + ' ' + year);
			//-->
		</script></center></b>
		
<center><b><div id='MyClockDisplay' class='clock' onload='showTime()'></div> 
</center></b>
<script type='text/javascript'>function showTime(){var date=new Date(); var h=date.getHours(); var m=date.getMinutes(); var s=date.getSeconds(); var session='AM'; if(h==0){h=12;}if(h > 12){h=h - 12; session='PM';}h=(h < 10) ? '0' + h : h; m=(m < 10) ? '0' + m : m; s=(s < 10) ? '0' + s : s; var time=h + ':' + m + ':' + s + ' ' + session; document.getElementById('MyClockDisplay').innerText=time; document.getElementById('MyClockDisplay').textContent=time; setTimeout(showTime, 1000);}showTime(); </script></b>

<font color='#FFFFFF'>
				    <div class="left">
                        <span class="title">Akses Internet WiFi</span>
                        <h2 class="total">Tanpa Batasan Kuota</h2>
                    </div>
<center><form action='$loginpath' method='post' name='Login_Form'>
            <input type='hidden' name='challenge' value='$challenge'>
            <input type='hidden' name='uamip' value='$uamip'>
            <input type='hidden' name='uamport' value='$uamport'>
            <input type='hidden' name='userurl' value='$userurl'>
                                <div class="form-group basic">
                                    <div class="input-wrapper">
                                        <label class="label" for="username">Masukan Voucher</label>

										    <input type='text' id='idusr' class='$center form-control' name='UserName' placeholder='Masukan Kode Voucher' required='' autofocus=''/>

										    <input type='hidden' id='pass' class='$center form-control' name='Password' placeholder='Masukan Password Member' required='' autofocus=''/>
            <input type='hidden' name='button'  value='Login'>
<!-- =========GANTI TRIAL DISINI BRO======= -->
 <script>
            function change() {
                var idusr = document.getElementById('idusr').value = 'Trial';
            }
        </script>

                                        <i class="clear-input">
                                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
											<path fill="#FFFFFF" d="M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2C6.47,2 2,6.47 2,12C2,17.53 6.47,22 12,22C17.53,22 22,17.53 22,12C22,6.47 17.53,2 12,2M14.59,8L12,10.59L9.41,8L8,9.41L10.59,12L8,14.59L9.41,16L12,13.41L14.59,16L16,14.59L13.41,12L16,9.41L14.59,8Z" />
											</svg>
                                        </i>
                                    </div>
                                </div>
                                <div class="form-group basic">
								 <button class=' btn btn-primary btn-block btn-lg' onClick='\'javascript:popUp('$loginpath?res=popup1&uamip=$uamip&uamport=$uamport')\'> LOGIN </button>
<br>


            </div>
            <center><form action='$loginpath' method='post' name='Login_Form'>
            <input type='hidden' name='challenge' value='$challenge'>
            <input type='hidden' name='uamip' value='$uamip'>
            <input type='hidden' name='uamport' value='$uamport'>
            <input type='hidden' name='userurl' value='$userurl'>

</script>
<br>

</b>


                <!-- * Balance -->
                <!-- Wallet Footer -->
                <div class="wallet-footer">
                <div class="item">
                            <div class="">
                        <button class='icon-wrapper bg-danger'onClick='change()'><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
								<path fill="#ffffff" d="M15,14C12.33,14 7,15.33 7,18V20H23V18C23,15.33 17.67,14 15,14M6,10V7H4V10H1V12H4V15H6V12H9V10M15,12A4,4 0 0,0 19,8A4,4 0 0,0 15,4A4,4 0 0,0 11,8A4,4 0 0,0 15,12Z" />
								</svg>
							</div>
                            <strong><b>COBA<br>GRATIS</b></strong>
                        </a>
                    </div>
                           </script>
<div class="item">
<div class="">
            <button class='icon-wrapper'onClick='togglePasswordVisibility()'><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
								<path fill="#ffffff" d="M10 12C12.21 12 14 10.21 14 8S12.21 4 10 4 6 5.79 6 8 7.79 12 10 12M10 6C11.11 6 12 6.9 12 8S11.11 10 10 10 8 9.11 8 8 8.9 6 10 6M12 20H2V17C2 14.33 7.33 13 10 13C10.91 13 12.13 13.16 13.35 13.47C13.26 13.8 13.2 14.15 13.2 14.5V15.39C12.22 15.1 11.1 14.9 10 14.9C7.03 14.9 3.9 16.36 3.9 17V18.1H12C12 18.13 12 18.17 12 18.2V20M20.8 17H16.5V14.5C16.5 13.7 17.2 13.2 18 13.2S19.5 13.7 19.5 14.5V15H20.8V14.5C20.8 13.1 19.4 12 18 12S15.2 13.1 15.2 14.5V17C14.6 17 14 17.6 14 18.2V21.7C14 22.4 14.6 23 15.2 23H20.7C21.4 23 22 22.4 22 21.8V18.3C22 17.6 21.4 17 20.8 17Z" />
								</svg>
								
								
							</div>
                            <strong>LOGIN<br>MEMBER</strong>
                            
                        

                        </a>
                    </div>
                    <div class="item">
                        <a href="faq.html">
                            <div class="icon-wrapper bg-success">
                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
								<path fill="#ffffff" d="M13,8A4,4 0 0,1 9,12A4,4 0 0,1 5,8A4,4 0 0,1 9,4A4,4 0 0,1 13,8M17,18V20H1V18C1,15.79 4.58,14 9,14C13.42,14 17,15.79 17,18M20.5,14.5V16H19V14.5H20.5M18.5,9.5H17V9A3,3 0 0,1 20,6A3,3 0 0,1 23,9C23,9.97 22.5,10.88 21.71,11.41L21.41,11.6C20.84,12 20.5,12.61 20.5,13.3V13.5H19V13.3C19,12.11 19.6,11 20.59,10.35L20.88,10.16C21.27,9.9 21.5,9.47 21.5,9A1.5,1.5 0 0,0 20,7.5A1.5,1.5 0 0,0 18.5,9V9.5Z" />
								</svg>
							</div>
                            <strong>BUTUH<br>BANTUAN</strong>
                        </a>
                    </div>
					<div class="item">
                      <a href="pembayaran.html">
                            <div class="icon-wrapper bg-warning">
                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
								   <path fill="#ffffff" d="M7 4C4.8 4 3 5.8 3 8S4.8 12 7 12 11 10.2 11 8 9.2 4 7 4M7 10C5.9 10 5 9.1 5 8S5.9 6 7 6 9 6.9 9 8 8.1 10 7 10M7 14C3.1 14 0 15.8 0 18V20H11V18H2C2 17.4 3.8 16 7 16C8.8 16 10.2 16.5 11 17V14.8C9.9 14.3 8.5 14 7 14M22 4H15C13.9 4 13 4.9 13 6V18C13 19.1 13.9 20 15 20H22C23.1 20 24 19.1 24 18V6C24 4.9 23.1 4 22 4M16 18H15V6H16V18M22 18H18V6H22V18Z" />
								</svg>
							</div>
                            <strong>TRANSAKSI<br>VIA QRIS</strong>
                        </a>
                    </div>

                </div>
                <!-- * Wallet Footer -->
            </div>
        </div>
        <!-- Wallet Card -->

        <!-- Paket Unggulan -->
        <div class="section">
            <div class="row mt-2">
                <div class="col-6">
                    <div class="stat-box">
                        <div class="title">Paket 1 Hari</div>
                        <div class="value text-success">Rp 4.000</div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="stat-box">
                        <div class="title">Paket 2 Hari</div>
                        <div class="value text-danger">Rp 8.000</div>
                    </div>
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-6">
                    <div class="stat-box">
                        <div class="title">Paket 7 Hari</div>
                        <div class="value">Rp 18.000</div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="stat-box">
                        <div class="title">Paket 30 Hari</div>
                        <div class="value">Rp 40.000</div>
                    </div>
                </div>
            </div>
        </div>
        <!-- * Paket Unggulan -->


        <!-- Paket Lainnya -->
        <div class="section full mt-2 mb-2">
            <div class="section-heading padding">
                <h5 class="title">Paket Lainnya</h5>
                <a href="paket.html" class="link">Lihat Semua</a>
            </div>
        </div>
        <!-- * Paket Lainnya -->

<font color='#6104FF'>
        <!-- app footer -->
        <div class="appFooter">
            <div class="footer-title">
                Support by <script src="assets/config/supported.js"></script>
            </div>
            © Design by <a href="https://www.bdr.my.id"><script src="assets/config/namawifi.js"></script></a>
        </div>
        <!-- * app footer -->

    </div>
    <!-- * App Capsule -->


    <!-- Menu Bawah -->
    <div class="appBottomMenu">
        <a href="#" class="item active">
            <div class="col">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
				<path fill="#6236FF" d="M17 14H19V17H22V19H19V22H17V19H14V17H17V14M5 20V12H2L12 3L22 12H17V10.19L12 5.69L7 10.19V18H12C12 18.7 12.12 19.37 12.34 20H5Z" />
				</svg>
				<strong>Beranda</strong>
            </div>
        </a>
        <a href="paket.html" class="item">
            <div class="col">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
				<path fill="#6236FF" d="M19 23.3L18.4 22.8C16.4 20.9 15 19.7 15 18.2C15 17 16 16 17.2 16C17.9 16 18.6 16.3 19 16.8C19.4 16.3 20.1 16 20.8 16C22 16 23 16.9 23 18.2C23 19.7 21.6 20.9 19.6 22.8L19 23.3M18 2C19.1 2 20 2.9 20 4V13.08L19 13L18 13.08V4H13V12L10.5 9.75L8 12V4H6V20H13.08C13.2 20.72 13.45 21.39 13.8 22H6C4.9 22 4 21.1 4 20V4C4 2.9 4.9 2 6 2H18Z" />
				</svg>
				<strong>Paket</strong>
            </div>
        </a>
		<a href="https://laksa19.github.io/myqr/" class="item">
            <div class="col">
                <div class="action-button large">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
				<path fill="#ffffff" d="M4,4H10V10H4V4M20,4V10H14V4H20M14,15H16V13H14V11H16V13H18V11H20V13H18V15H20V18H18V20H16V18H13V20H11V16H14V15M16,15V18H18V15H16M4,20V14H10V20H4M6,6V8H8V6H6M16,6V8H18V6H16M6,16V18H8V16H6M4,11H6V13H4V11M9,11H13V15H11V13H9V11M11,6H13V10H11V6M2,2V6H0V2A2,2 0 0,1 2,0H6V2H2M22,0A2,2 0 0,1 24,2V6H22V2H18V0H22M2,18V22H6V24H2A2,2 0 0,1 0,22V18H2M22,22V18H24V22A2,2 0 0,1 22,24H18V22H22Z" />
				</svg>
                </div>
            </div>
        </a>
		<a href="faq.html" class="item">
            <div class="col">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
				<path fill="#6236FF" d="M18,15H6L2,19V3A1,1 0 0,1 3,2H18A1,1 0 0,1 19,3V14A1,1 0 0,1 18,15M23,9V23L19,19H8A1,1 0 0,1 7,18V17H21V8H22A1,1 0 0,1 23,9M8.19,4C7.32,4 6.62,4.2 6.08,4.59C5.56,5 5.3,5.57 5.31,6.36L5.32,6.39H7.25C7.26,6.09 7.35,5.86 7.53,5.7C7.71,5.55 7.93,5.47 8.19,5.47C8.5,5.47 8.76,5.57 8.94,5.75C9.12,5.94 9.2,6.2 9.2,6.5C9.2,6.82 9.13,7.09 8.97,7.32C8.83,7.55 8.62,7.75 8.36,7.91C7.85,8.25 7.5,8.55 7.31,8.82C7.11,9.08 7,9.5 7,10H9C9,9.69 9.04,9.44 9.13,9.26C9.22,9.08 9.39,8.9 9.64,8.74C10.09,8.5 10.46,8.21 10.75,7.81C11.04,7.41 11.19,7 11.19,6.5C11.19,5.74 10.92,5.13 10.38,4.68C9.85,4.23 9.12,4 8.19,4M7,11V13H9V11H7M13,13H15V11H13V13M13,4V10H15V4H13Z" />
				</svg>
				<strong>FAQ</strong>
            </div>
        </a>
        <a href="kontak.html" class="item">
            <div class="col">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="24" height="24" viewBox="0 0 24 24">
				<path fill="#6236FF" d="M6,17C6,15 10,13.9 12,13.9C14,13.9 18,15 18,17V18H6M15,9A3,3 0 0,1 12,12A3,3 0 0,1 9,9A3,3 0 0,1 12,6A3,3 0 0,1 15,9M3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V5A2,2 0 0,0 19,3H5C3.89,3 3,3.9 3,5Z" />
				</svg>
				<strong>Kontak</strong>
            </div>
        </a>
    </div>
    <!-- * Menu Bawah -->

	<!-- Script Tambahan -->
    <script type="text/javascript">
        var username = document.login.username;
        var password = document.login.password;

        function setpass() {
            var user = username.value
            password.value = user;
            console.log(user);
        }
        username.onchange = setpass;
    </script>
	<!-- Script Tambahan -->

    <!-- ========= JS Files =========  -->
    <!-- Bootstrap -->
    <script src="assets/js/lib/bootstrap.bundle.min.js"></script>
    <!-- Base Js File -->
    <script src="assets/js/base.js"></script>
  <script src="js/jquery-3.3.1.slim.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
 <script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/custom.js">
<script>
            function change() {
                var idusr = document.getElementById('user').value = 'TRIAL';
                var idpsw = document.getElementById('pass').value = 'TRIAL';
            }
        </script>
            <span class='password-toggle-icon' onclick='togglePasswordVisibility()'>
</span>
</div>
<style>
  .password-toggle-icon {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-10%);
    width: 60px;
    height: 60px;
    background-image: url('/hotspotlogin/template/rgb/img/mata.gif');
    background-repeat: no-repeat;
    background-size: contain;
    cursor: pointer;
  }
  .password-toggle-icon.active {
    background-image: url('/hotspotlogin/template/rby/img/mata.gif');
  }
</style>
<script>
  function togglePasswordVisibility() {
    var passwordInput = document.getElementById('pass');
    var passwordIcon = document.querySelector('.password-toggle-icon');

    if (passwordInput.getAttribute('type') == 'password') {
      passwordInput.setAttribute('type', 'text');
      passwordIcon.classList.add('active');
    } else {
      passwordInput.setAttribute('type', 'password');
      passwordIcon.classList.remove('active');
    }
  }


</script>

</body>

</html>


END;


?>
