<?php
/*

 */


echo "<div class='container-fluid'><div class='alert-wrapper  text-center'>";

echo "<div class='alert alert-primary text-center' role='alert'>
    $h1Loggedin";
echo "</div>";
echo "<br>";
echo "<a class='btn btn-danger' href=\"http://$uamip:$uamport/logoff\" role='button'>$centerLogout</a>";
echo "</div></div>";
