document.write('OpenWrt')
//Ganti BADARO.ID dengan Nama Wifi Agan
//Jangan Menghapus kode scriptnya