document.write('PROMO PASANG BARU MULAI 299RIBU.... HUBUNGU KAMI MELALUI MENU BANTUAN')
//Sesuaikan
//Jangan Menghapus kode scriptnya