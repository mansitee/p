document.write('Toko Badaro, RT 13/RW 04 Cigadung<br>Desa Karyamukti Kecamatan Pataruman<br>Kota Banjar - Jawa Barat')
//Sesuaikan, Jika ingin menggunakan karakter "enter" gunakan kode <br>
//Jangan Menghapus kode scriptnya